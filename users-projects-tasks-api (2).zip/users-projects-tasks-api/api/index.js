require('dotenv').config();

const app = require('../src/app');
const connectDB = require('../src/config/db');

// Serverless functions can be reused between invocations (warm starts),
// so we cache the DB connection instead of reconnecting on every request.
let isConnected = false;

module.exports = async (req, res) => {
  if (!isConnected) {
    await connectDB();
    isConnected = true;
  }
  return app(req, res);
};
